from os import listdir
from os.path import join
import random
from NetWorks.denoising_rgb import DenoiseNet,Get_gradient_nopadding
from PIL import Image
import torch
import torch.utils.data as data
import torchvision.transforms as transforms
import os
import argparse

# Testing settings
parser = argparse.ArgumentParser(description='pix2pix-pytorch-implementation')
parser.add_argument('--dataset',     type=str, default='./dataset', help='facades')
parser.add_argument('--direction',   type=str, default='b2a',       help='a2b or b2a')
parser.add_argument('--nepochs',     type=int, default=590,          help='saved model of which epochs')
parser.add_argument('--cuda',        type=str, default='0',         help='use cuda')
opt = parser.parse_args()


device = torch.device("cuda:0" if opt.cuda else "cpu")
model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
if os.path.exists('d:/assist'):
    model_restoration = torch.load(model_path).to(device)
else:
    model_restoration = DenoiseNet()