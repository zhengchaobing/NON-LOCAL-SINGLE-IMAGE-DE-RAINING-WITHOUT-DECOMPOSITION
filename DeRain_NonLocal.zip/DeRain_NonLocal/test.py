from __future__ import print_function
import argparse
import os
import torch
import torchvision.transforms as transforms
from utils import is_image_file,load_img, load_img2, save_img

# Testing settings
parser = argparse.ArgumentParser(description='pix2pix-pytorch-implementation')
parser.add_argument('--dataset',     type=str,   default='./dataset4', help='facades')
parser.add_argument('--direction',   type=str,   default='b2a',       help='a2b or b2a')
parser.add_argument('--cuda',        action='store_true', default=True, help='use cuda?')
parser.add_argument('--nepochs',     type=int,   default=170,         help='saved model of which epochs')
opt = parser.parse_args()
print(opt)

device = torch.device("cuda:0" if opt.cuda else "cpu")
model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)
net_g = torch.load(model_path).to(device)


image_dir = "./Real_data/Real_data/"
image_filenames = [x for x in os.listdir(image_dir) if is_image_file(x)]

transform_list = [transforms.ToTensor(),transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]
transform = transforms.Compose(transform_list)
net_g.eval()
with torch.no_grad():
    for image_name in image_filenames:
        img = load_img(image_dir + image_name)

        img = transform(img)
        input = img.unsqueeze(0).to(device)
        out = net_g(input)
        out_img = out.detach().squeeze(0).cpu()

        if not os.path.exists(os.path.join("result", opt.dataset)):
            os.makedirs(os.path.join("result", opt.dataset))

        save_img(out_img, "/netdisk-2.2-home/ZCB/Dehaze_Data/dataset3/Results2/{}".format(image_name))
