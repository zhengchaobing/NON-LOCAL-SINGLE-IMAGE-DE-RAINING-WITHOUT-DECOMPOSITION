###########################################################################
# Created by: CASIA IVA
# Email: jliu@nlpr.ia.ac.cn
# Copyright (c) 2018
###########################################################################

import numpy as np
import torch
import math
from torch.nn import Module, Sequential, Conv2d, ReLU,AdaptiveMaxPool2d, AdaptiveAvgPool2d, \
    NLLLoss, BCELoss, CrossEntropyLoss, AvgPool2d, MaxPool2d, Parameter, Linear, Sigmoid, Softmax, Dropout, Embedding
from torch.nn import functional as F
from torch.autograd import Variable
torch_ver = torch.__version__[:3]
import torch.nn as nn

__all__ = ['PAM_Module', 'CAM_Module']

def conv(in_channels, out_channels, kernel_size, bias=True, padding = 1, stride = 1):
    return nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size//2),  bias=bias, stride = stride)

####Position attention module
class PAM_Module(Module):
    """ Position attention module"""
    #Ref from SAGAN
    def __init__(self, in_dim):
        super(PAM_Module, self).__init__()
        self.chanel_in = in_dim

        self.query_conv  = Conv2d(in_channels=in_dim, out_channels=in_dim//16,  kernel_size=1)
        self.key_conv    = Conv2d(in_channels=in_dim, out_channels=in_dim//16,  kernel_size=1)
        self.value_conv = Conv2d(in_channels=in_dim, out_channels=in_dim,       kernel_size=1)
        self.gamma = Parameter(torch.zeros(1))

        self.softmax = Softmax(dim=-1)
    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X (HxW) X (HxW)
        """
        m_batchsize, C, height, width = x.size()
        proj_query  = self.query_conv(x).view(m_batchsize, -1, width*height).permute(0, 2, 1)
        proj_key     = self.key_conv(x).view(m_batchsize, -1, width*height)
        energy = torch.bmm(proj_query, proj_key)
        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(m_batchsize, -1, width*height)

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(m_batchsize, C, height, width)

        out = self.gamma*out + x
        return out

####Channel attention module
class CAM_Module(Module):
    """ Channel attention module"""
    def __init__(self, in_dim):
        super(CAM_Module, self).__init__()
        self.chanel_in = in_dim

        self.gamma = Parameter(torch.zeros(1))
        self.softmax  = Softmax(dim=-1)
    def forward(self,x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X C X C
        """
        m_batchsize, C, height, width = x.size()
        proj_query =  x.view(m_batchsize, C, -1)
        proj_key    =  x.view(m_batchsize, C, -1).permute(0, 2, 1)
        energy       =  torch.bmm(proj_query, proj_key)
        energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy)-energy
        attention      = self.softmax(energy_new)
        proj_value = x.view(m_batchsize, C, -1)

        out = torch.bmm(attention, proj_value)
        out = out.view(m_batchsize, C, height, width)

        out = self.gamma*out + x
        return out

##Nonlocal Dual Attention Block (DAB)
class DAB(nn.Module):
    def __init__(self, conv=conv, n_feat=64, kernel_size=3, bias=True, bn=False, act=nn.ReLU(True)):
        super(DAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        act = nn.PReLU(n_feat)
        modules_down1 = [nn.Conv2d(n_feat, n_feat, (3, 3), stride=2, padding=1, bias=True)]
        modules_down1.append(act)
        modules_down2 = [nn.Conv2d(n_feat, n_feat, (3, 3), stride=2, padding=1, bias=True)]
        self.body_down1 = nn.Sequential(*modules_down1)
        self.body_down2 = nn.Sequential(*modules_down2)

        modules_up1 = [nn.ConvTranspose2d(2 * n_feat, n_feat, 3, stride=2, padding=1, output_padding=1, bias=True)]
        modules_up1.append(act)
        modules_up2 = [nn.ConvTranspose2d(n_feat, n_feat, 3, stride=2, padding=1, output_padding=1, bias=True)]
        self.body_up1 = nn.Sequential(*modules_up1)
        self.body_up2 = nn.Sequential(*modules_up2)

        self.SA = PAM_Module(n_feat)  ## Spatial Attention
        self.CA = CAM_Module(n_feat)  ## Channel Attention
        self.body = nn.Sequential(*modules_body)
        self.conv1x1 = nn.Conv2d(n_feat , n_feat, kernel_size=1)

    def forward(self, x):
        res = self.body(x)

        res1 = self.body_down1(res)
        res2 = self.body_down2(res1)

        sa_branch = self.SA(res2)
        ca_branch = self.CA(res2)
        resc = torch.cat([sa_branch, ca_branch], dim=1)

        resup1 = self.body_up1(resc)   + res1
        resup2 = self.body_up2(resup1) + res

        res = self.conv1x1(resup2)
        res += x
        return res

## Recursive Residual Group (RRG)
class RRG(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, act, num_dab):
        super(RRG, self).__init__()
        modules_body = []
        modules_body = [DAB(conv, n_feat, kernel_size, bias=True, bn=True, act=act) for _ in range(num_dab)]
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res

#####DenoiseNet
class DeRainNet(nn.Module):
    def __init__(self, conv=conv):
        super(DeRainNet, self).__init__()
        num_rrg  = 4
        num_dab  = 6
        n_feats  = 64
        kernel_size = 3
        reduction = 16
        inp_chans = 3
        act = nn.PReLU(n_feats)

        modules_head = [conv(inp_chans, n_feats, kernel_size=kernel_size, stride=1)]
        modules_body = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab) for _ in range(num_rrg)]
        modules_body.append(conv(n_feats, n_feats, kernel_size))
        modules_body.append(act)
        modules_tail = [conv(n_feats, inp_chans, kernel_size)]

        self.head = nn.Sequential(*modules_head)
        self.body = nn.Sequential(*modules_body)
        self.tail = nn.Sequential(*modules_tail)

    def forward(self, image):
        x = self.head(image)
        x = self.body(x)
        x = self.tail(x)
        x = image + x
        x = torch.clamp(x, -1.0, 1.0)
        return x


if __name__ == '__main__':
    img  = torch.randn(1, 3, 256, 256)
    net3 = DeRainNet()
    out1 = net3(img)
    print(out1.size())

