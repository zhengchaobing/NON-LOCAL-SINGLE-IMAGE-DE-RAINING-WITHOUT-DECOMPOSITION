from __future__ import print_function
import argparse
import os
from math import log10
from NetWorks.denoising_rgb import Get_gradient_nopadding
from VGG import VGGLoss
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torch.backends.cudnn as cudnn
from networks import define_G, define_D, GANLoss, get_scheduler, update_learning_rate
from data import get_training_set, get_test_set
from ERFNet import DeRainNet
from NetWorks.denoising_rgb import DenoiseNet
from test_Demo import DeRainNet
import numpy as np
from utils import calculate_cos_distance,calculate_L1_L2_distance
from skimage.measure.simple_metrics import compare_psnr
# Training settings
parser = argparse.ArgumentParser(description='pix2pix-pytorch-implementation')
parser.add_argument('--dataset',         type=str,    default='./dataset4', help='facades')
parser.add_argument('--batch_size',      type=int,    default=6,            help='training batch size')
parser.add_argument('--test_batch_size', type=int,    default=1,            help='testing batch size')
parser.add_argument('--direction',       type=str,    default='b2a',        help='a2b or b2a')
parser.add_argument('--input_nc',        type=int,    default=3,            help='input image channels')
parser.add_argument('--output_nc',       type=int,    default=3,            help='output image channels')
parser.add_argument('--ngf',             type=int,    default=64,           help='generator filters in first conv layer')
parser.add_argument('--ndf',             type=int,    default=64,           help='discriminator filters in first conv layer')
parser.add_argument('--epoch_count',     type=int,    default=1,            help='the starting epoch count')
parser.add_argument('--niter',           type=int,    default=100,          help='# of iter at starting learning rate')
parser.add_argument('--niter_decay',     type=int,    default=200000,         help='# of iter to linearly decay learning rate to zero')
parser.add_argument('--lr',              type=float,  default=0.00005,       help='initial learning rate for adam')
parser.add_argument('--lr_policy',       type=str,    default='lambda',     help='learning rate policy: lambda|step|plateau|cosine')
parser.add_argument('--lr_decay_iters',  type=int,    default=50,           help='multiply by a gamma every lr_decay_iters iterations')
parser.add_argument('--beta1',           type=float,  default=0.5,          help='beta1 for adam. default=0.5')
parser.add_argument('--cuda',            action='store_true',               default=True, help='use cuda?')
parser.add_argument('--threads',         type=int,    default=4,            help='number of threads for data loader to use')
parser.add_argument('--seed',            type=int,    default=830,          help='random seed to use. Default=1234')
parser.add_argument('--lamb_MSE',        type=int,    default=150.0,        help='weight on L1 term in objective')
parser.add_argument('--lamb_feature',    type=int,    default=1.0,          help='weight on L1 term in objective')
parser.add_argument('--lamb_gradient',   type=int,    default=1.0,          help='weight on L1 term in objective')
parser.add_argument('--nepochs',         type=int,    default=410,          help='restare to train saved model of which epochs')
opt = parser.parse_args()
print(opt)

if opt.cuda and not torch.cuda.is_available():
    raise Exception("No GPU found, please run without --cuda")
cudnn.benchmark = True

torch.manual_seed(opt.seed)
if opt.cuda:
    torch.cuda.manual_seed(opt.seed)

print('===> Loading datasets')
train_set = get_training_set(opt.dataset, opt.direction)
test_set  = get_test_set(opt.dataset, opt.direction)
training_data_loader = DataLoader(dataset=train_set,  num_workers=opt.threads,  batch_size = opt.batch_size,      shuffle=True)
testing_data_loader  = DataLoader(dataset=test_set,   num_workers=opt.threads,  batch_size = opt.test_batch_size, shuffle=False)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

print('===> Building models')
model_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, opt.nepochs)

model_restoration = DeRainNet()
model_restoration = torch.nn.DataParallel(model_restoration)
if os.path.exists(model_path):
    print('===> Success load models')
    model_restoration = torch.load(model_path).to(device)
    opt.epoch_count=opt.nepochs + 1
else:
    model_restoration.to(torch.device('cuda'))

model_restoration.to(torch.device('cuda'))
Get_gradient =Get_gradient_nopadding().to(torch.device('cuda'))
vgg_loss = VGGLoss().to(torch.device('cuda'))
calculate_cos_loss = calculate_cos_distance().to(torch.device('cuda'))

criterionMSE = nn.MSELoss().to(torch.device('cuda'))
criterionL1  = nn.L1Loss().to(torch.device('cuda'))
L1_L2_distance = calculate_L1_L2_distance().to(torch.device('cuda'))
# setup optimizer
optimizer_ft    = optim.Adam(model_restoration.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
net_g_scheduler = get_scheduler(optimizer_ft, opt)

a = [];
b = [];
if os.path.exists('a.npy'):
    a = np.load("a.npy").tolist()
if os.path.exists('b.npy'):
    b = np.load("b.npy").tolist()
for epoch in range(opt.epoch_count, opt.niter + opt.niter_decay + 1):
    model_restoration.train()
    # train
    for iteration, batch in enumerate(training_data_loader, 1):
        # forward
        real_a, real_b = batch[0].to(device), batch[1].to(device)
        optimizer_ft.zero_grad()

        fake_a = model_restoration(real_b)

        loss_gradient = calculate_cos_loss(real_a, fake_a)
        loss_MSE = L1_L2_distance(real_a,  fake_a,  2.0) * opt.lamb_MSE
        loss_feature = vgg_loss(real_a,  fake_a) * opt.lamb_feature

        Loss = loss_MSE + loss_gradient + loss_feature
        Loss.backward()

        optimizer_ft.step()
        print("===> Epoch[{}]({}/{}): Loss: {:.4f} loss_gradient: {:.4f} loss_feature: {:.4f} loss_MSE: {:.4f}".format(epoch, iteration, len(training_data_loader), Loss.item() , loss_gradient.item() ,loss_feature, loss_MSE.item()))
    update_learning_rate(net_g_scheduler, optimizer_ft)


    #checkpoint, Loss.item()
    if epoch % 5 == 0:
        if not os.path.exists("checkpoint"):
            os.mkdir("checkpoint")
        if not os.path.exists(os.path.join("checkpoint", opt.dataset)):
            os.mkdir(os.path.join("checkpoint", opt.dataset))
        net_g_model_out_path = "checkpoint/{}/netG_model_epoch_{}.pth".format(opt.dataset, epoch)
        torch.save(model_restoration, net_g_model_out_path)
        print("Checkpoint saved to {}".format("checkpoint" + opt.dataset))

    if epoch % 5 == 0:
        model_restoration.eval()
        with torch.no_grad():
            avg_psnr = 0.0
            for batch in testing_data_loader:
                real_a, real_b = batch[0].to(device), batch[1].to(device)
                prediction = model_restoration(real_b)

                img = prediction[0, :, :, :].clone()
                img =  (img.float().cpu().numpy()+1.0)/2.0

                img0 = real_a[0, :, :, :].clone()
                img0 = (img0.float().cpu().numpy()+1.0)/2.0

                psnr = compare_psnr(img0, img, data_range=1.0)
                avg_psnr += psnr

            print("===> Avg. PSNR: {:.6f} dB".format(avg_psnr / len(testing_data_loader)))
            a.append(epoch);
            b.append(avg_psnr / len(testing_data_loader));
    np.save("a.npy", a)
    np.save("b.npy", b)