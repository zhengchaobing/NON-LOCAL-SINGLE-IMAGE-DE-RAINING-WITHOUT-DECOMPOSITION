from os import listdir
from os.path import join
import random

from PIL import Image
import torch
import torch.utils.data as data
import torchvision.transforms as transforms



a = Image.open(".//dataset//test//False//293.png").convert('RGB')
b = Image.open(".//dataset//test//Truth//293.png").convert('RGB')
a = a.resize((256, 256), Image.BICUBIC)
b = b.resize((256, 256), Image.BICUBIC)

a.save('.//result//Resize_Imgs//1.png')
b.save('.//result//Resize_Imgs//2.png')